# Copyright 2021 The KubeEdge Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from copy import deepcopy

from sedna.common.utils import get_host_ip
from sedna.common.class_factory import ClassFactory, ClassType
from sedna.service.server import InferenceServer
from sedna.service.client import ModelClient, LCReporter
from sedna.common.constant import K8sResourceKind
from sedna.core.base import JobBase
import re

HUGGINGFACE_PATH_PATTERN = r'^[a-zA-Z0-9][\w\-]*/[a-zA-Z0-9][\w\-\.]*$'

__all__ = ("JointInference", "BigModelService")


class BigModelService(JobBase):
    """
    Large model services implemented
    Provides RESTful interfaces for large-model inference.

    Parameters
    ----------
    estimator : Instance, big model
        An instance with the high-level API that greatly simplifies
        machine learning programming. Estimators encapsulate training,
        evaluation, prediction, and exporting for your model.

    Examples
    --------
    >>> Estimator = xgboost.XGBClassifier()
    >>> BigModelService(estimator=Estimator).start()
    """

    def __init__(self, estimator=None):
        """
        Initial a big model service for JointInference
        :param estimator: Customize estimator
        """

        super(BigModelService, self).__init__(estimator=estimator)
        self.local_ip = self.get_parameters("BIG_MODEL_BIND_IP", get_host_ip())
        self.port = int(self.get_parameters("BIG_MODEL_BIND_PORT", "5000"))

    def start(self):
        """
        Start inference rest server
        """

        if callable(self.estimator):
            self.estimator = self.estimator()
        if not os.path.exists(self.model_path):
            raise FileExistsError(f"{self.model_path} miss")
        else:
            self.estimator.load(self.model_path)
        app_server = InferenceServer(model=self, servername=self.job_name,
                                     host=self.local_ip, http_port=self.port)
        app_server.start()

    def train(self, train_data,
              valid_data=None,
              post_process=None,
              **kwargs):
        """todo: no support yet"""

    def inference(self, data=None, post_process=None, **kwargs):
        """
        Inference task for JointInference

        Parameters
        ----------
        data: BaseDataSource
            datasource use for inference, see
            `sedna.datasources.BaseDataSource` for more detail.
        post_process: function or a registered method
            effected after `estimator` inference.
        kwargs: Dict
            parameters for `estimator` inference,
            Like:  `ntree_limit` in Xgboost.XGBClassifier

        Returns
        -------
        inference result
        """

        callback_func = None
        if callable(post_process):
            callback_func = post_process
        elif post_process is not None:
            callback_func = ClassFactory.get_cls(
                ClassType.CALLBACK, post_process)

        res = self.estimator.predict(data, **kwargs)
        if callback_func:
            res = callback_func(res)
        return res


class JointInference(JobBase):
    """
    Sedna provide a framework make sure under the condition of limited
    resources on the edge, difficult inference tasks are offloaded to the
    cloud to improve the overall performance, keeping the throughput.

    Parameters
    ----------
    estimator : Instance
        An instance with the high-level API that greatly simplifies
        machine learning programming. Estimators encapsulate training,
        evaluation, prediction, and exporting for your model.
    hard_example_mining : Dict
        HEM algorithms with parameters which has registered to ClassFactory,
        see `sedna.algorithms.hard_example_mining` for more detail.

    Examples
    --------
    >>> Estimator = keras.models.Sequential()
    >>> ji_service = JointInference(
            estimator=Estimator,
            hard_example_mining={
                "method": "IBT",
                "param": {
                    "threshold_img": 0.9
                }
            }
        )

    Notes
    -----
    Sedna provide an interface call `get_hem_algorithm_from_config` to build
    the `hard_example_mining` parameter from CRD definition.
    """

    def __init__(
            self,
            estimator=None,
            cloud=None,
            drafter=None,
            verifier=None,
            hard_example_mining: dict = None,
            LCReporter_enable: bool = True
        ):
        super(JointInference, self).__init__(estimator=estimator)

        self.job_kind = K8sResourceKind.JOINT_INFERENCE_SERVICE.value
        self.local_ip = get_host_ip()

        report_msg = {
            "name": self.worker_name,
            "namespace": self.config.namespace,
            "ownerName": self.job_name,
            "ownerKind": self.job_kind,
            "kind": "inference",
            "results": []
        }
        period_interval = int(self.get_parameters("LC_PERIOD", "30"))

        self.LCReporter_enable = LCReporter_enable

        if self.LCReporter_enable:
            self.lc_reporter = LCReporter(
                lc_server=self.config.lc_server,
                message=report_msg,
                period_interval=period_interval
            )
            self.lc_reporter.setDaemon(True)
            self.lc_reporter.start()

        if callable(self.estimator):
            self.estimator = self.estimator()

        self.drafter = drafter
        self.verifier = verifier
        self.speculative_runtime = self.drafter is not None and self.verifier is not None
        if callable(self.drafter):
            self.drafter = self.drafter()
        if callable(self.verifier):
            self.verifier = self.verifier()

        check_huggingface_repo = lambda x: bool(re.match(HUGGINGFACE_PATH_PATTERN, x))

        if self.speculative_runtime:
            if self.drafter is not None and hasattr(self.drafter, "load"):
                self.drafter.load()
            if self.verifier is not None and hasattr(self.verifier, "load"):
                self.verifier.load()
        else:
            if not os.path.exists(self.model_path) and not check_huggingface_repo(self.model_path):
                raise FileExistsError(f"{self.model_path} miss")
            if self.estimator is not None:
                self.estimator.load(model_url=self.model_path)

        if cloud is None and not self.speculative_runtime:
            self.remote_ip = self.get_parameters(
            "BIG_MODEL_IP", self.local_ip)
            self.port = int(self.get_parameters("BIG_MODEL_PORT", "5000"))

            self.cloud = ModelClient(
                service_name=self.job_name,
                host=self.remote_ip,
                port=self.port
            )
        else:
            self.cloud = cloud

        self.hard_example_mining_algorithm = None
        if not hard_example_mining:
            hard_example_mining = self.get_hem_algorithm_from_config()
        if hard_example_mining:
            hem = hard_example_mining.get("method", "IBT")
            hem_parameters = hard_example_mining.get("param", {})
            self.hard_example_mining_algorithm = ClassFactory.get_cls(
                ClassType.HEM, hem
            )(**hem_parameters)

    @classmethod
    def get_hem_algorithm_from_config(cls, **param):
        """
        get the `algorithm` name and `param` of hard_example_mining from crd

        Parameters
        ----------
        param : Dict
            update value in parameters of hard_example_mining

        Returns
        -------
        dict
            e.g.: {"method": "IBT", "param": {"threshold_img": 0.5}}

        Examples
        --------
        >>> JointInference.get_hem_algorithm_from_config(
                threshold_img=0.9
            )
        {"method": "IBT", "param": {"threshold_img": 0.9}}
        """
        return cls.parameters.get_algorithm_from_api(
            algorithm="HEM",
            **param
        )


    def _get_edge_result(self, data, callback_func, **kwargs):
        edge_result = self.estimator.predict(data, **kwargs)
        res = deepcopy(edge_result)

        if callback_func:
            res = callback_func(res)

        if self.LCReporter_enable:
            self.lc_reporter.update_for_edge_inference()

        return res, edge_result

    def _get_cloud_result(self, data, post_process, **kwargs):
        cloud_result = self.cloud.inference(data, post_process=post_process, **kwargs)

        res = deepcopy(cloud_result)

        if self.LCReporter_enable:
            self.lc_reporter.update_for_collaboration_inference()

        return res, cloud_result

    def _check_hem_algorithm(self):
        if self.hard_example_mining_algorithm is None:
            raise ValueError("Hard example mining algorithm is not set.")

    def _supports_token_level_speculative_decoding(self):
        drafter_required = [
            "inference",
            "start_session",
            "step",
            "close_session",
        ]
        verifier_required = ["inference", "start_session", "verify", "close_session"]
        return all(hasattr(self.drafter, name) for name in drafter_required) and all(
            hasattr(self.verifier, name) for name in verifier_required
        )

    def _run_token_level_speculative_decoding(self, data, callback_func=None, **kwargs):
        inference_mode = kwargs.get("inference_mode", getattr(self.drafter, "inference_mode", "collaboration"))

        if inference_mode == "cloud-only":
            result = self.verifier.inference(data=data, **kwargs)
            if self.LCReporter_enable:
                self.lc_reporter.update_for_collaboration_inference()
            if callback_func:
                result = callback_func(result)
            return [False, result, None, result]

        if inference_mode == "edge-only":
            edge_result = self.drafter.inference(
                data=data,
                **kwargs,
            )
            if self.LCReporter_enable:
                self.lc_reporter.update_for_edge_inference()
            result = callback_func(edge_result) if callback_func else edge_result
            return [False, result, edge_result, None]

        draft_session = self.drafter.start_session(data=data, **kwargs)
        verify_session = self.verifier.start_session(data=data, draft_session=draft_session, **kwargs)
        request = draft_session.get("request", data if isinstance(data, dict) else {"query": data})

        try:
            round_index = 0
            collaboration_result = None
            feedback = None
            while True:
                round_index += 1
                draft_payload = self.drafter.step(
                    draft_session,
                    feedback=feedback,
                    **kwargs
                )

                verify_payload = self.verifier.verify(
                    verify_session,
                    draft_output=draft_payload,
                    **kwargs
                )
                control = {
                    "stop": bool((verify_payload or {}).get("stop", False)),
                    "progress": bool((verify_payload or {}).get("progress", True)),
                }
                if (verify_payload or {}).get("result") is not None:
                    collaboration_result = verify_payload.get("result")
                feedback = (verify_payload or {}).get("feedback")
                draft_session["_pending_feedback"] = feedback

                if not bool(control.get("progress", True)):
                    raise RuntimeError(
                        "Speculative decoding made no progress according to algorithm runtime state."
                    )

                if bool(control.get("stop", False)):
                    break
        finally:
            draft_close_result = self.drafter.close_session(draft_session, request=request)
            self.verifier.close_session(verify_session, request=request)
            if collaboration_result is None and draft_close_result is not None:
                collaboration_result = draft_close_result

        if collaboration_result is None:
            raise RuntimeError(
                "Speculative decoding stopped without returning a final result."
            )

        if self.LCReporter_enable:
            self.lc_reporter.update_for_collaboration_inference()
        result = callback_func(collaboration_result) if callback_func else collaboration_result
        return [False, result, None, None]

    def inference(self, data=None, post_process=None, **kwargs):
        """
        Inference task with JointInference

        Parameters
        ----------
        data: BaseDataSource
            datasource use for inference, see
            `sedna.datasources.BaseDataSource` for more detail.
        post_process: function or a registered method
            effected after `estimator` inference.
        kwargs: Dict
            parameters for `estimator` inference,
            Like:  `ntree_limit` in Xgboost.XGBClassifier

        Returns
        -------
        if is hard sample : bool
        inference result : object
        result from little-model : object
        result from big-model: object
        """

        callback_func = None
        if callable(post_process):
            callback_func = post_process
        elif post_process is not None:
            callback_func = ClassFactory.get_cls(
                ClassType.CALLBACK, post_process)

        # - inference-then-mining
        # - mining-then-inference
        # - self-design
        # - mining-free
        mining_mode = kwargs.get("mining_mode", "inference-then-mining")

        is_hard_example = False
        sepeculative_decoding = False

        edge_result, cloud_result = None, None

        if mining_mode == "inference-then-mining":
            res, edge_result = self._get_edge_result(data, callback_func, **kwargs)

            self._check_hem_algorithm()

            is_hard_example = self.hard_example_mining_algorithm(res)
            if is_hard_example:
                res, cloud_result = self._get_cloud_result(data, post_process=post_process, **kwargs)

        elif mining_mode == "mining-then-inference":
            self._check_hem_algorithm()

            is_hard_example = self.hard_example_mining_algorithm(data)
            if is_hard_example:
                if not sepeculative_decoding:
                    res, cloud_result = self._get_cloud_result(data, post_process=post_process, **kwargs)
                else:
                    pass
            else:
                res, edge_result = self._get_edge_result(data, callback_func, **kwargs)

        elif mining_mode == "self-design":
            res = self.estimator.predict(data, **kwargs)
            return callback_func(res) if callback_func else res

        elif mining_mode == "mining-free":
            if self._supports_token_level_speculative_decoding():
                return self._run_token_level_speculative_decoding(
                    data=data,
                    callback_func=callback_func,
                    **kwargs,
                )
            raise ValueError(
                "Mining-free mode requires drafter/verifier runtimes "
                "implementing inference/start_session/step/verify/close_session."
            )

        else:
            raise ValueError(
                "Mining Mode must be in "
                "['mining-then-inference', 'inference-then-mining', "
                "'self-design', 'mining-free']"
            )

        return [is_hard_example, res, edge_result, cloud_result]
